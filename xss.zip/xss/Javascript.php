<html>
<div name="form" align="center">
	  <form name="form1" method="POST" action="#" >
	  Enter your name : <input type="text" name="Name"/><br><br>
	  <input type="submit" name="submit" id="submit" value="Click me"/>
	  </form>
	  </div>



</html>
<?php
if ( isset( $_POST['submit'] ) ) { 

echo '<script>alert("Hello ',$_POST['Name'],'");</script>';


}

?>

