<html>
<div name="form" align="center">
	  <form name="form1" method="POST" action="#" >
	  Enter the site you want to visit <input type="text" name="site"/><br>
	  Eg: google.com<br><br>
	  <input type="submit" name="submit" id="submit" value="Submit"/>
	  </form>
	  </div>


</html>
<?php
if ( isset( $_POST['submit'] ) ) { 

echo '<a href="//',$_POST['site'],'">click here</a> to visit the website';


}

?>
