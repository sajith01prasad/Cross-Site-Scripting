<html>
<div name="login" align="center">
	  <form name="loginForm" method="POST" action="#" >
	  User name <input type="text" name="user_name"/><br><br>
	  
	  Password  <input type="text" name="password"/><br><br>
	  <input type="submit" name="submit" id="submit" value="Sign in"/>
	  </form>
	  </div>

</html>
<?php
if ( isset( $_POST['submit'] ) ) { 
$pwd =$_POST['password'];
//echo 'Edit Password<br>';
//echo  '<br>';
echo 'Current password<input type="text" value="',$pwd,'"/>(Edit this textbox with the new password)<br><br><input type="submit" name="submit1" id="submit1" value="save changes">';


}

?>
