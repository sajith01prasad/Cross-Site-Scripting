

<html>
<div name="login" align="center">
	  <form name="loginForm" method="POST" action="#" >
	  First name <input type="text" name="first_name"/><br><br>
	  
	  Last  name <input type="text" name="last_name"/><br><br>
	  <input type="submit" name="submit" id="submit" value="Sign in"/>
	  </form>
	  </div>
</html>
<?php
if ( isset( $_POST['submit'] ) ) { 

echo'Hello '.$_POST['first_name'].' '.$_POST['last_name'];


}

?>